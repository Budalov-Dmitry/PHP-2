<h2>Товар</h2>

<div>
    <img src="/img/big/<?=$product->image?>" alt="">
    <p><?=$product->description?></p>
    <p>price: <?=$product->price?></p>
    <button>Купить</button>
</div>